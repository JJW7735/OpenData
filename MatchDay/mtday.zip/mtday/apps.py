from django.apps import AppConfig


class MtdayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mtday'
